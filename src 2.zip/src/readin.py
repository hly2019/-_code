import numpy as np
from PIL import Image
import utils
import jittor as jt

subdir = "../数据/input/"
dir_num = 1

pic_name_pref = "result_img"
pic_num = 1

# src = np.asarray(Image.open(filename))[...,:3]
def read_and_mask(filepath, maskpath, targetpath):
    src = np.asarray(Image.open(filepath))[...,:3]
    mask = np.asarray(Image.open(maskpath))[...,:3]
    shape = src.shape
    raw = shape[0]
    col = shape[1]
    output = np.zeros((raw, col, 3))
    for i in range(raw):
        for j in range(col):
            ori_rgb = src[i][j]
            mask_rgb = mask[i][j]
            if mask_rgb[0] < 25 and mask_rgb[1] < 25 and mask_rgb[2] < 25:
                output[i][j] = mask_rgb
            else:
                output[i][j] = ori_rgb
    Image.fromarray((output).astype(np.uint8)).save(targetpath)


def calcConv(filepath, maskedpath):
    A = np.asarray(Image.open(filepath))[...,:3]
    kernel = utils.bfs_get_kernel(maskedpath)
    js = jt.array(A)
    jk = jt.array(kernel)
    jy = utils.calcConvJittor(js, jk).fetch_sync()
    return jy




read_and_mask("../数据/down_input1.jpg", "../数据/down_input1_mask.jpg", "./masked.png")
# utils.bfs_get_kernel("./masked.png")
y = calcConv("../数据/input1/down_result_img001.jpg", "kernel.jpg")
# print(y)

