import cv2

down_input1 = cv2.imread("../数据/input1.jpg")

down_input1_masked = cv2.imread("../数据/input1_mask.jpg")

down_test = cv2.imread("../数据/input1/result_img001.jpg")

down_input1 = cv2.pyrDown(down_input1)
down_input1_masked = cv2.pyrDown(down_input1_masked)
down_test = cv2.pyrDown(down_test)

down_input1 = cv2.pyrDown(down_input1)
down_input1_masked = cv2.pyrDown(down_input1_masked)
down_test = cv2.pyrDown(down_test)

cv2.imwrite("../数据/down_input1.jpg", down_input1)

cv2.imwrite("../数据/down_input1_mask.jpg", down_input1_masked)

cv2.imwrite("../数据/input1/down_result_img001.jpg", down_test)

# cv2.waitKey()
# cv2.destroyAllWindows()
